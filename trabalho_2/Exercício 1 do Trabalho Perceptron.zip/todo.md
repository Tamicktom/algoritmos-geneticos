# Lista de Tarefas - Exercício 1 Perceptron (Iris Dataset)

- [x] Extrair o enunciado do exercício 1 do PDF
- [ ] Criar ambiente de trabalho e baixar o dataset Iris
- [ ] Implementar o algoritmo Perceptron
- [ ] Dividir o dataset em conjuntos de treinamento, validação e teste (70%/15%/15%)
- [ ] Testar diferentes pesos de inicialização
- [ ] Testar diferentes taxas de aprendizado
- [ ] Avaliar o impacto da normalização dos dados
- [ ] Gerar gráficos de Erro Médio Quadrático e/ou Entropia Cruzada
- [ ] Criar matrizes de confusão para cada subconjunto
- [ ] Documentar os resultados e conclusões
- [ ] Preparar a solução final em formato markdown
